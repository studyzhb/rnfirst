export default {
    nav1:require('../images/nav1.png'),
    nav1_outline:require('../images/nav1-outline.png'),
    nav2:require('../images/nav2.png'),
    nav2_outline:require('../images/nav2-outline.png'),
    nav3:require('../images/nav3.png'),
    nav3_outline:require('../images/nav3-outline.png'),
}