const final={

    //是否实名认证
    ISREALNAME:1,
    ISPAYPASS:'',
    ALIPAYTYPE:2,
    BALANCETYPE:1,
    ORDERLISTNOFINISHED:1,
    ORDERLISTFINISHED:2,
    //登录状态
    LOGINDEFAULT:0,//等待中
    LOGINFINISHED:1,
    LOGINNOFINISHED:2,
    //认证状态
    AUTHORING:1,
    BACKGOODS:2,
    PICKUPGOODS:1,
}

export default  final;