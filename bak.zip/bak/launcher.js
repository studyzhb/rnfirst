import React,{Component} from 'react';
import {
	AppRegistry
} from 'react-native';

import Eapp from './app/root';

AppRegistry.registerComponent('wdrn', () => Eapp);